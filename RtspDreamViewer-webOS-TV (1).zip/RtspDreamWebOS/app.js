(function () {
  'use strict';

  var STORAGE_KEY = 'rtsp_webos_settings_v1';
  var SERVICE_URI = 'luna://com.rtspdream.webos.service';
  var BACKOFF_DELAYS_SEC = [2, 4, 8, 15];

  var launchedAsScreensaver =
    typeof window.location !== 'undefined' &&
    typeof window.location.search === 'string' &&
    window.location.search.indexOf('mode=screensaver') !== -1;

  var state = {
    settings: loadSettings(),
    currentScreen: 'viewer',
    screensaverMode: launchedAsScreensaver,
    showGearOverlay: false,
    gearTimer: null,
    reconnectTimer: null,
    countdownTimer: null,
    retryAttempt: 0,
    isTesting: false,
    activePlaybackUrl: null,
    ws: null,
    mediaSource: null,
    sourceBuffer: null,
    mseQueue: [],
    mseObjectUrl: null,
    liveWatchTimer: null,
    snapshotTimer: null,
    lastStats: null,
    videoVerifiedPlaying: false,
    streamStartAt: 0,
    firstFragmentAt: 0
  };

  var viewerScreen = document.getElementById('viewer-screen');
  var settingsScreen = document.getElementById('settings-screen');
  var videoEl = document.getElementById('rtsp-video');
  var mjpegEl = document.getElementById('mjpeg-surface');
  var statusOverlay = document.getElementById('status-overlay');
  var statusSpinner = document.getElementById('status-spinner');
  var statusTitle = document.getElementById('status-title');
  var statusDetail = document.getElementById('status-detail');
  var floatingGearBtn = document.getElementById('floating-settings-btn');

  var btnBack = document.getElementById('btn-back');
  var settingsHeading = document.getElementById('settings-heading');
  var inputStreamUrl = document.getElementById('input-stream-url');
  var inputRelayUrl = document.getElementById('input-relay-url');
  var urlError = document.getElementById('url-error');
  var toggleTcp = document.getElementById('toggle-tcp');
  var toggleMute = document.getElementById('toggle-mute');
  var testResultBanner = document.getElementById('test-result-banner');
  var testBannerTitle = document.getElementById('test-banner-title');
  var testBannerDetail = document.getElementById('test-banner-detail');
  var btnSaveTest = document.getElementById('btn-save-test');
  var btnOpenViewer = document.getElementById('btn-open-viewer');
  var btnStartScreensaver = document.getElementById('btn-start-screensaver');

  var draftTcp = state.settings.forceRtpTcp;
  var draftMute = state.settings.muteAudio;

  function getBridgeConstructor() {
    if (typeof window.WebOSServiceBridge === 'function') return window.WebOSServiceBridge;
    if (typeof window.PalmServiceBridge === 'function') return window.PalmServiceBridge;
    return null;
  }

  function safePlay(el, onError) {
    try {
      var p = el.play();
      if (p && typeof p.catch === 'function') {
        p.catch(function (err) {
          if (onError) onError(err);
        });
      }
    } catch (err) {
      if (onError) onError(err);
    }
  }

  function getDecodedFrameCount() {
    try {
      if (typeof videoEl.getVideoPlaybackQuality === 'function') {
        var q = videoEl.getVideoPlaybackQuality();
        if (q && typeof q.totalVideoFrames === 'number') return q.totalVideoFrames;
      }
      if (typeof videoEl.webkitDecodedFrameCount === 'number') {
        return videoEl.webkitDecodedFrameCount;
      }
    } catch (e) {}
    return -1;
  }

  function isMjpegOrImageUrl(url) {
    return /^https?:\/\/.*(mjpg|mjpeg|video\.cgi|snapshot|\.jpe?g(\?|$))/i.test(url || '');
  }

  function isSnapshotUrl(url) {
    return /^https?:\/\/.*(snapshot|\.jpe?g(\?|$))/i.test(url || '');
  }

  function loadSettings() {
    try {
      var raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) {
        var parsed = JSON.parse(raw);
        return {
          streamUrl: typeof parsed.streamUrl === 'string' ? parsed.streamUrl.trim() : '',
          relayBaseUrl: typeof parsed.relayBaseUrl === 'string' ? parsed.relayBaseUrl.trim() : '',
          forceRtpTcp: typeof parsed.forceRtpTcp === 'boolean' ? parsed.forceRtpTcp : true,
          muteAudio: typeof parsed.muteAudio === 'boolean' ? parsed.muteAudio : true
        };
      }
    } catch (e) {}
    return {
      streamUrl: '',
      relayBaseUrl: '',
      forceRtpTcp: true,
      muteAudio: true
    };
  }

  function saveSettings(next) {
    state.settings = next;
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    } catch (e) {}
  }

  function validateUrl(url) {
    var trimmed = (url || '').trim();
    if (!trimmed) {
      return 'Enter an RTSP, HLS, or MJPEG stream URL (e.g. rtsp://192.168.1.50:554/stream).';
    }
    if (!/^(rtsps?|https?):\/\//i.test(trimmed)) {
      return 'URL must start with rtsp://, rtsps://, http://, or https://.';
    }
    return null;
  }

  function callLunaService(serviceUri, method, params, onSuccess, onError) {
    var BridgeCtor = getBridgeConstructor();
    if (!BridgeCtor) {
      if (onError) onError('WebOSServiceBridge / PalmServiceBridge unavailable (run packaged .ipk on LG webOS TV)');
      return null;
    }
    try {
      var bridge = new BridgeCtor();
      bridge.onservicecallback = function (msg) {
        try {
          var res = JSON.parse(msg);
          if (res && res.returnValue === false) {
            if (onError) onError(res.errorText || 'Service call failed');
          } else if (onSuccess) {
            onSuccess(res);
          }
        } catch (err) {
          if (onError) onError(err && err.message ? err.message : String(err));
        }
      };
      bridge.call(serviceUri + '/' + method, JSON.stringify(params || {}));
      return bridge;
    } catch (err) {
      if (onError) onError(err && err.message ? err.message : String(err));
      return null;
    }
  }

  var tvPowerBridge = null;
  function registerScreensaverSuppressor() {
    var BridgeCtor = getBridgeConstructor();
    if (!BridgeCtor || state.screensaverMode) return;
    try {
      tvPowerBridge = new BridgeCtor();
      tvPowerBridge.onservicecallback = function (msg) {
        try {
          var data = JSON.parse(msg);
          if (data && data.state === 'Active' && state.currentScreen === 'viewer') {
            var reply = new BridgeCtor();
            reply.call(
              'luna://com.webos.service.tvpower/power/responseScreenSaverRequest',
              JSON.stringify({
                clientName: 'com.rtspdream.webos',
                ack: false,
                timestamp: data.timestamp
              })
            );
          }
        } catch (e) {}
      };
      tvPowerBridge.call(
        'luna://com.webos.service.tvpower/power/registerScreenSaverRequest',
        JSON.stringify({
          subscribe: true,
          clientName: 'com.rtspdream.webos'
        })
      );
    } catch (e) {}
  }

  function setStatus(visible, title, detail, showSpinner) {
    if (!visible) {
      statusOverlay.classList.add('hidden');
      return;
    }
    // Keep connecting/error overlay visible even in screensaver mode until real video renders
    statusOverlay.classList.remove('hidden');
    statusTitle.textContent = title || '';
    statusDetail.textContent = detail || '';
    statusSpinner.style.display = showSpinner ? 'block' : 'none';
  }

  function clearReconnectTimers() {
    if (state.reconnectTimer) {
      window.clearTimeout(state.reconnectTimer);
      state.reconnectTimer = null;
    }
    if (state.countdownTimer) {
      window.clearInterval(state.countdownTimer);
      state.countdownTimer = null;
    }
  }

  function cleanupMse() {
    if (state.liveWatchTimer) {
      window.clearInterval(state.liveWatchTimer);
      state.liveWatchTimer = null;
    }
    if (state.snapshotTimer) {
      window.clearInterval(state.snapshotTimer);
      state.snapshotTimer = null;
    }
    if (state.ws) {
      try {
        state.ws.onclose = null;
        state.ws.onerror = null;
        state.ws.onmessage = null;
        state.ws.close();
      } catch (e) {}
      state.ws = null;
    }
    state.mseQueue = [];
    state.sourceBuffer = null;
    state.lastStats = null;
    state.videoVerifiedPlaying = false;
    state.firstFragmentAt = 0;
    if (state.mediaSource) {
      try {
        if (state.mediaSource.readyState === 'open') {
          state.mediaSource.endOfStream();
        }
      } catch (e) {}
      state.mediaSource = null;
    }
    if (state.mseObjectUrl) {
      try { URL.revokeObjectURL(state.mseObjectUrl); } catch (e) {}
      state.mseObjectUrl = null;
    }
  }

  function stopPlayback() {
    clearReconnectTimers();
    cleanupMse();
    videoEl.pause();
    videoEl.removeAttribute('src');
    videoEl.load();
    mjpegEl.removeAttribute('src');
    mjpegEl.classList.add('hidden');
    videoEl.classList.remove('hidden');
    state.activePlaybackUrl = null;
    callLunaService(SERVICE_URI, 'stopStream', {});
  }

  function formatDiagnosticDetail(urlLabel) {
    var parts = [];
    if (state.lastStats) {
      var st = state.lastStats;
      parts.push('RTP pkts: ' + (st.rtpPackets || 0));
      parts.push('SPS: ' + (st.hasSps ? 'OK' : 'no'));
      parts.push('PPS: ' + (st.hasPps ? 'OK' : 'no'));
      parts.push('IDR: ' + (st.hasKeyframe ? 'OK' : 'wait'));
      parts.push('Frags: ' + (st.fragments || 0));
      if (st.width > 0) parts.push('Stream: ' + st.width + 'x' + st.height);
    }
    var frames = getDecodedFrameCount();
    parts.push('TV Video: ' + videoEl.videoWidth + 'x' + videoEl.videoHeight + (frames >= 0 ? ' (' + frames + ' frames)' : ''));
    if (urlLabel) parts.push(urlLabel);
    return parts.join(' · ');
  }

  function checkVideoActuallyRendering() {
    var frames = getDecodedFrameCount();
    var hasDimensions = videoEl.videoWidth > 0 && videoEl.videoHeight > 0;
    var hasFrames = frames === -1 ? videoEl.readyState >= 2 : frames > 0;
    if (hasDimensions && hasFrames) {
      state.videoVerifiedPlaying = true;
      state.retryAttempt = 0;
      clearReconnectTimers();
      setStatus(false);
      return true;
    }
    return false;
  }

  function flushMseQueue() {
    var sb = state.sourceBuffer;
    if (!sb || sb.updating || state.mseQueue.length === 0) return;

    try {
      if (sb.buffered.length > 0 && videoEl.currentTime > 12) {
        var start = sb.buffered.start(0);
        var safeEnd = videoEl.currentTime - 6;
        if (safeEnd > start + 2) {
          sb.remove(start, safeEnd);
          return;
        }
      }
    } catch (e) {}

    var nextBuf = state.mseQueue.shift();
    try {
      sb.appendBuffer(nextBuf);
    } catch (err) {
      scheduleReconnect('MSE append error: ' + (err && err.message ? err.message : String(err)));
    }
  }

  function startMseWebSocketPlayback(wsUrl) {
    cleanupMse();
    state.streamStartAt = Date.now();
    setStatus(true, 'Connecting local H.264 stream...', formatDiagnosticDetail(wsUrl), true);

    var MediaSrc = window.MediaSource || window.WebKitMediaSource;
    if (!MediaSrc) {
      scheduleReconnect('MediaSource API unavailable on this webOS browser');
      return;
    }

    var ms = new MediaSrc();
    state.mediaSource = ms;
    state.mseObjectUrl = URL.createObjectURL(ms);
    videoEl.src = state.mseObjectUrl;

    var pendingCodec = null;
    var receivedFirstBinary = false;

    function initSourceBuffer(mime) {
      if (state.sourceBuffer || !state.mediaSource || state.mediaSource.readyState !== 'open') return;
      var chosen = mime;
      if (!MediaSrc.isTypeSupported(chosen)) {
        chosen = 'video/mp4; codecs="avc1.42E01E"';
      }
      if (!MediaSrc.isTypeSupported(chosen)) {
        scheduleReconnect('Unsupported H.264 codec: ' + mime);
        return;
      }
      try {
        var sb = state.mediaSource.addSourceBuffer(chosen);
        sb.addEventListener('updateend', function () {
          if (videoEl.buffered.length > 0) {
            var end = videoEl.buffered.end(videoEl.buffered.length - 1);
            if (videoEl.paused) {
              safePlay(videoEl);
            }
            if (end - videoEl.currentTime > 1.8) {
              try {
                videoEl.currentTime = Math.max(0, end - 0.25);
              } catch (seekErr) {}
            }
          }
          checkVideoActuallyRendering();
          flushMseQueue();
        });
        sb.addEventListener('error', function () {
          scheduleReconnect('TV SourceBuffer error while decoding H.264 stream');
        });
        state.sourceBuffer = sb;
        flushMseQueue();
      } catch (sbErr) {
        scheduleReconnect('Failed to initialize TV H.264 decoder: ' + (sbErr && sbErr.message ? sbErr.message : String(sbErr)));
      }
    }

    ms.addEventListener('sourceopen', function () {
      if (pendingCodec) {
        initSourceBuffer(pendingCodec);
      }
    });

    var ws = new WebSocket(wsUrl);
    ws.binaryType = 'arraybuffer';
    state.ws = ws;

    ws.onmessage = function (ev) {
      if (typeof ev.data === 'string') {
        try {
          var msg = JSON.parse(ev.data);
          if (msg.type === 'stats') {
            state.lastStats = msg;
            if (!state.videoVerifiedPlaying && !state.reconnectTimer) {
              setStatus(
                true,
                msg.hasKeyframe ? 'Decoding H.264 video frames...' : 'Waiting for H.264 keyframe...',
                formatDiagnosticDetail(''),
                true
              );
            }
          } else if (msg.type === 'codec' && msg.mime) {
            pendingCodec = msg.mime;
            initSourceBuffer(msg.mime);
          } else if (msg.type === 'error') {
            scheduleReconnect(msg.message || 'RTSP bridge error');
          }
        } catch (e) {}
        return;
      }

      if (!receivedFirstBinary) {
        receivedFirstBinary = true;
        state.firstFragmentAt = Date.now();
      }

      if (!state.sourceBuffer && pendingCodec) {
        initSourceBuffer(pendingCodec);
      } else if (!state.sourceBuffer && !pendingCodec) {
        pendingCodec = 'video/mp4; codecs="avc1.4D4029"';
        initSourceBuffer(pendingCodec);
      }

      if (state.mseQueue.length > 60) {
        if (state.sourceBuffer) {
          state.mseQueue = state.mseQueue.slice(-10);
        } else {
          state.mseQueue = [state.mseQueue[0]].concat(state.mseQueue.slice(-9));
        }
      }
      state.mseQueue.push(new Uint8Array(ev.data));
      flushMseQueue();
    };

    ws.onerror = function () {
      scheduleReconnect('Local RTSP bridge WebSocket error');
    };

    ws.onclose = function () {
      if (state.currentScreen === 'viewer' && !state.reconnectTimer) {
        scheduleReconnect('RTSP bridge disconnected');
      }
    };

    state.liveWatchTimer = window.setInterval(function () {
      if (state.currentScreen !== 'viewer' || state.reconnectTimer) return;

      if (videoEl.buffered.length > 0) {
        var liveEnd = videoEl.buffered.end(videoEl.buffered.length - 1);
        if (liveEnd - videoEl.currentTime > 2.5) {
          try {
            videoEl.currentTime = Math.max(0, liveEnd - 0.3);
          } catch (e) {}
        }
      }

      if (checkVideoActuallyRendering()) return;

      var now = Date.now();
      var elapsed = now - state.streamStartAt;
      var st = state.lastStats;

      if (!receivedFirstBinary && elapsed > 9000) {
        if (st && (st.rtpPackets || 0) === 0) {
          scheduleReconnect('RTSP connected, but 0 video packets arrived. Check camera stream / LAN firewall.');
        } else {
          scheduleReconnect('No H.264 keyframe received within 9s (' + formatDiagnosticDetail('') + ').');
        }
        return;
      }

      if (state.firstFragmentAt > 0 && now - state.firstFragmentAt > 7000 && !state.videoVerifiedPlaying) {
        scheduleReconnect(
          'H.264 data received, but LG TV decoded 0 frames (' +
            formatDiagnosticDetail('') +
            '). Try camera sub-stream (subtype=1), H.264 Baseline/Main, go2rtc Relay URL, or MJPEG URL.'
        );
      }
    }, 1000);
  }

  function startMjpegPlayback(url) {
    cleanupMse();
    videoEl.pause();
    videoEl.removeAttribute('src');
    videoEl.classList.add('hidden');
    mjpegEl.classList.remove('hidden');

    state.activePlaybackUrl = url;
    setStatus(true, 'Loading MJPEG / Snapshot stream...', url, true);

    mjpegEl.onload = function () {
      state.videoVerifiedPlaying = true;
      state.retryAttempt = 0;
      clearReconnectTimers();
      setStatus(false);
    };
    mjpegEl.onerror = function () {
      if (state.currentScreen === 'viewer') {
        scheduleReconnect('Failed to load MJPEG / Snapshot image from ' + url);
      }
    };

    if (isSnapshotUrl(url)) {
      var loadSnap = function () {
        var sep = url.indexOf('?') === -1 ? '?' : '&';
        mjpegEl.src = url + sep + '_t=' + Date.now();
      };
      loadSnap();
      state.snapshotTimer = window.setInterval(loadSnap, 500);
    } else {
      mjpegEl.src = url;
    }
  }

  function startPlayback() {
    if (!state.settings.streamUrl) return;
    clearReconnectTimers();
    cleanupMse();

    var url = state.settings.streamUrl.trim();
    var relay = (state.settings.relayBaseUrl || '').trim().replace(/\/+$/, '');

    if (isMjpegOrImageUrl(url)) {
      startMjpegPlayback(url);
      return;
    }

    mjpegEl.classList.add('hidden');
    mjpegEl.removeAttribute('src');
    videoEl.classList.remove('hidden');
    videoEl.muted = !!state.settings.muteAudio;
    videoEl.volume = state.settings.muteAudio ? 0 : 1;

    setStatus(true, 'Connecting to stream...', url, true);

    if (/^https?:\/\//i.test(url)) {
      state.activePlaybackUrl = url;
      videoEl.src = url;
      safePlay(videoEl, function (err) {
        scheduleReconnect(err && err.message ? err.message : 'Playback blocked');
      });
      return;
    }

    if (relay) {
      var relayPlayUrl = relay + '/api/stream.mp4?src=' + encodeURIComponent(url);
      state.activePlaybackUrl = relayPlayUrl;
      videoEl.src = relayPlayUrl;
      safePlay(videoEl, function (err) {
        scheduleReconnect(err && err.message ? err.message : 'Relay playback failed');
      });
      return;
    }

    setStatus(true, 'Starting Luna RTSP bridge...', url, true);
    callLunaService(
      SERVICE_URI,
      'startStream',
      {
        rtspUrl: url,
        forceRtpTcp: state.settings.forceRtpTcp
      },
      function (res) {
        if (res && res.wsUrl && (window.MediaSource || window.WebKitMediaSource)) {
          state.activePlaybackUrl = res.wsUrl;
          startMseWebSocketPlayback(res.wsUrl);
        } else if (res && res.httpUrl) {
          state.activePlaybackUrl = res.httpUrl;
          videoEl.src = res.httpUrl;
          safePlay(videoEl, function (err) {
            scheduleReconnect(err && err.message ? err.message : 'Playback failed');
          });
        } else {
          scheduleReconnect('RTSP service did not return a local stream URL.');
        }
      },
      function (err) {
        scheduleReconnect(err || 'Failed to start Luna RTSP service');
      }
    );
  }

  function scheduleReconnect(reason) {
    if (state.currentScreen !== 'viewer') return;
    if (state.reconnectTimer) return;

    cleanupMse();
    state.retryAttempt += 1;
    var idx = Math.min(state.retryAttempt - 1, BACKOFF_DELAYS_SEC.length - 1);
    var remaining = BACKOFF_DELAYS_SEC[idx];

    setStatus(
      true,
      'Stream interrupted · Reconnecting in ' + remaining + 's (Attempt ' + state.retryAttempt + ')',
      reason || '',
      true
    );

    state.countdownTimer = window.setInterval(function () {
      remaining -= 1;
      if (remaining > 0) {
        setStatus(
          true,
          'Stream interrupted · Reconnecting in ' + remaining + 's (Attempt ' + state.retryAttempt + ')',
          reason || '',
          true
        );
      }
    }, 1000);

    state.reconnectTimer = window.setTimeout(function () {
      clearReconnectTimers();
      if (state.currentScreen === 'viewer') {
        startPlayback();
      }
    }, BACKOFF_DELAYS_SEC[idx] * 1000);
  }

  videoEl.addEventListener('loadeddata', checkVideoActuallyRendering);
  videoEl.addEventListener('playing', checkVideoActuallyRendering);

  videoEl.addEventListener('waiting', function () {
    if (!state.reconnectTimer && !state.screensaverMode) {
      setStatus(true, 'Buffering stream...', formatDiagnosticDetail(''), true);
    }
  });

  videoEl.addEventListener('error', function () {
    if (!state.activePlaybackUrl) return;
    var msg = videoEl.error ? 'Media error code ' + videoEl.error.code : 'Stream connection lost';
    scheduleReconnect(msg);
  });

  videoEl.addEventListener('ended', function () {
    if (!state.activePlaybackUrl) return;
    scheduleReconnect('Stream ended by remote host');
  });

  window.addEventListener('online', function () {
    if (state.currentScreen === 'viewer' && state.reconnectTimer) {
      clearReconnectTimers();
      startPlayback();
    }
  });

  function showViewer(asScreensaver) {
    state.screensaverMode = !!asScreensaver;
    state.currentScreen = 'viewer';
    settingsScreen.classList.add('hidden');
    viewerScreen.classList.remove('hidden');
    hideFloatingGear();
    startPlayback();
  }

  function showSettings(optionalError) {
    state.screensaverMode = false;
    state.currentScreen = 'settings';
    stopPlayback();
    hideFloatingGear();
    viewerScreen.classList.add('hidden');
    settingsScreen.classList.remove('hidden');

    var hasUrl = !!state.settings.streamUrl;
    settingsHeading.textContent = hasUrl ? 'Stream & Screensaver Settings' : 'Configure RTSP Stream';
    btnBack.classList.toggle('hidden', !hasUrl);
    btnOpenViewer.classList.toggle('hidden', !hasUrl);
    btnStartScreensaver.classList.toggle('hidden', !hasUrl);

    inputStreamUrl.value = state.settings.streamUrl;
    inputRelayUrl.value = state.settings.relayBaseUrl;
    draftTcp = state.settings.forceRtpTcp;
    draftMute = state.settings.muteAudio;
    updateSwitchUI();

    if (optionalError) {
      urlError.textContent = optionalError;
      urlError.classList.remove('hidden');
    } else {
      urlError.classList.add('hidden');
    }

    window.setTimeout(function () {
      inputStreamUrl.focus();
    }, 50);
  }

  function updateSwitchUI() {
    toggleTcp.setAttribute('aria-checked', draftTcp ? 'true' : 'false');
    toggleMute.setAttribute('aria-checked', draftMute ? 'true' : 'false');
  }

  function revealFloatingGear() {
    if (state.screensaverMode || state.currentScreen !== 'viewer') return;
    state.showGearOverlay = true;
    floatingGearBtn.classList.remove('hidden');
    floatingGearBtn.focus();

    if (state.gearTimer) window.clearTimeout(state.gearTimer);
    state.gearTimer = window.setTimeout(hideFloatingGear, 4000);
  }

  function hideFloatingGear() {
    state.showGearOverlay = false;
    floatingGearBtn.classList.add('hidden');
    if (state.gearTimer) {
      window.clearTimeout(state.gearTimer);
      state.gearTimer = null;
    }
  }

  toggleTcp.addEventListener('click', function () {
    draftTcp = !draftTcp;
    updateSwitchUI();
  });

  toggleMute.addEventListener('click', function () {
    draftMute = !draftMute;
    updateSwitchUI();
  });

  btnSaveTest.addEventListener('click', function () {
    if (state.isTesting) return;
    var candidate = inputStreamUrl.value.trim();
    var validation = validateUrl(candidate);
    if (validation) {
      urlError.textContent = validation;
      urlError.classList.remove('hidden');
      testResultBanner.classList.add('hidden');
      return;
    }

    urlError.classList.add('hidden');
    var updated = {
      streamUrl: candidate,
      relayBaseUrl: inputRelayUrl.value.trim(),
      forceRtpTcp: draftTcp,
      muteAudio: draftMute
    };
    saveSettings(updated);
    btnBack.classList.remove('hidden');
    btnOpenViewer.classList.remove('hidden');
    btnStartScreensaver.classList.remove('hidden');

    state.isTesting = true;
    btnSaveTest.textContent = 'Testing Stream...';
    testResultBanner.classList.add('hidden');

    if (/^rtsp/i.test(candidate) && !updated.relayBaseUrl) {
      callLunaService(
        SERVICE_URI,
        'testStream',
        { rtspUrl: candidate, forceRtpTcp: updated.forceRtpTcp },
        function (res) {
          state.isTesting = false;
          btnSaveTest.textContent = 'Save & Test Stream';
          testResultBanner.className = 'test-banner success';
          testBannerTitle.textContent = 'Settings Saved & Stream Reachable';
          var resStr = res.width > 0 ? ' · ' + res.width + 'x' + res.height : '';
          testBannerDetail.textContent =
            (res.codec || 'H.264') + resStr + ' · ' + (updated.forceRtpTcp ? 'RTP over TCP' : 'RTP over UDP');
        },
        function (errText) {
          state.isTesting = false;
          btnSaveTest.textContent = 'Save & Test Stream';
          testResultBanner.className = 'test-banner error';
          testBannerTitle.textContent = 'Settings Saved · Stream Test Failed';
          testBannerDetail.textContent = errText;
        }
      );
    } else if (isMjpegOrImageUrl(candidate)) {
      var probeImg = new Image();
      var imgDone = false;
      var imgTimer = window.setTimeout(function () {
        if (imgDone) return;
        imgDone = true;
        state.isTesting = false;
        btnSaveTest.textContent = 'Save & Test Stream';
        testResultBanner.className = 'test-banner error';
        testBannerTitle.textContent = 'Settings Saved · Stream Test Timed Out';
        testBannerDetail.textContent = 'No image frame received within 8s from ' + candidate;
      }, 8000);
      probeImg.onload = function () {
        if (imgDone) return;
        imgDone = true;
        window.clearTimeout(imgTimer);
        state.isTesting = false;
        btnSaveTest.textContent = 'Save & Test Stream';
        testResultBanner.className = 'test-banner success';
        testBannerTitle.textContent = 'Settings Saved & MJPEG/Snapshot Reachable';
        testBannerDetail.textContent = probeImg.naturalWidth + 'x' + probeImg.naturalHeight + ' · Direct TV Image Stream';
      };
      probeImg.onerror = function () {
        if (imgDone) return;
        imgDone = true;
        window.clearTimeout(imgTimer);
        state.isTesting = false;
        btnSaveTest.textContent = 'Save & Test Stream';
        testResultBanner.className = 'test-banner error';
        testBannerTitle.textContent = 'Settings Saved · Stream Test Failed';
        testBannerDetail.textContent = 'Unable to load image from ' + candidate;
      };
      probeImg.src = candidate;
    } else {
      var probeUrl = updated.relayBaseUrl
        ? updated.relayBaseUrl.replace(/\/+$/, '') + '/api/stream.mp4?src=' + encodeURIComponent(candidate)
        : candidate;
      var probeVideo = document.createElement('video');
      var settled = false;
      var timeout = window.setTimeout(function () {
        if (settled) return;
        settled = true;
        probeVideo.removeAttribute('src');
        state.isTesting = false;
        btnSaveTest.textContent = 'Save & Test Stream';
        testResultBanner.className = 'test-banner error';
        testBannerTitle.textContent = 'Settings Saved · Stream Test Timed Out';
        testBannerDetail.textContent = 'No video metadata received within 10s from ' + probeUrl;
      }, 10000);

      probeVideo.muted = true;
      probeVideo.onloadedmetadata = function () {
        if (settled) return;
        settled = true;
        window.clearTimeout(timeout);
        var resLabel =
          probeVideo.videoWidth > 0 ? probeVideo.videoWidth + 'x' + probeVideo.videoHeight : 'Connected';
        probeVideo.removeAttribute('src');
        state.isTesting = false;
        btnSaveTest.textContent = 'Save & Test Stream';
        testResultBanner.className = 'test-banner success';
        testBannerTitle.textContent = 'Settings Saved & Stream Reachable';
        testBannerDetail.textContent = resLabel + ' · ' + (updated.relayBaseUrl ? 'Relay Gateway' : 'Direct HTTP/HLS');
      };
      probeVideo.onerror = function () {
        if (settled) return;
        settled = true;
        window.clearTimeout(timeout);
        state.isTesting = false;
        btnSaveTest.textContent = 'Save & Test Stream';
        testResultBanner.className = 'test-banner error';
        testBannerTitle.textContent = 'Settings Saved · Stream Test Failed';
        testBannerDetail.textContent = 'Unable to open ' + probeUrl;
      };
      probeVideo.src = probeUrl;
    }
  });

  btnOpenViewer.addEventListener('click', function () {
    showViewer(false);
  });

  btnStartScreensaver.addEventListener('click', function () {
    showViewer(true);
  });

  btnBack.addEventListener('click', function () {
    if (state.settings.streamUrl) {
      showViewer(false);
    }
  });

  floatingGearBtn.addEventListener('click', function (e) {
    e.stopPropagation();
    showSettings();
  });

  viewerScreen.addEventListener('click', function () {
    if (state.screensaverMode) {
      exitScreensaver();
      return;
    }
    if (state.showGearOverlay) {
      hideFloatingGear();
    } else {
      revealFloatingGear();
    }
  });

  function exitScreensaver() {
    if (launchedAsScreensaver) {
      stopPlayback();
      window.close();
    } else {
      showSettings();
    }
  }

  document.addEventListener('keydown', function (e) {
    var code = e.keyCode || e.which;

    if (state.currentScreen === 'viewer' && state.screensaverMode) {
      e.preventDefault();
      exitScreensaver();
      return;
    }

    if (code === 461 || e.key === 'Escape') {
      if (state.currentScreen === 'settings' && state.settings.streamUrl) {
        e.preventDefault();
        showViewer(false);
      } else if (state.currentScreen === 'viewer' && state.showGearOverlay) {
        e.preventDefault();
        hideFloatingGear();
      } else if (typeof window.webOS !== 'undefined' && window.webOS.platformBack) {
        window.webOS.platformBack();
      }
      return;
    }

    if (state.currentScreen === 'viewer') {
      if (code === 13 || code === 457 || code === 18) {
        if (state.showGearOverlay && document.activeElement === floatingGearBtn) {
          showSettings();
        } else {
          revealFloatingGear();
        }
        e.preventDefault();
      }
      return;
    }

    if (state.currentScreen === 'settings' && (code === 38 || code === 40)) {
      var focusables = Array.prototype.slice.call(
        settingsScreen.querySelectorAll('.tv-focusable:not(.hidden)')
      );
      var idx = focusables.indexOf(document.activeElement);
      if (idx === -1) {
        if (focusables[0]) focusables[0].focus();
        e.preventDefault();
        return;
      }
      var nextIdx = code === 40 ? Math.min(focusables.length - 1, idx + 1) : Math.max(0, idx - 1);
      focusables[nextIdx].focus();
      e.preventDefault();
    }
  });

  try {
    registerScreensaverSuppressor();
    if (!state.settings.streamUrl) {
      showSettings();
    } else {
      showViewer(launchedAsScreensaver);
    }
  } catch (bootErr) {
    showSettings('Startup error: ' + (bootErr && bootErr.message ? bootErr.message : String(bootErr)));
  }
})();
