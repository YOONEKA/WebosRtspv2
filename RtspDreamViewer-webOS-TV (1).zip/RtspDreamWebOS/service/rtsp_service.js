'use strict';

var net = require('net');
var http = require('http');
var crypto = require('crypto');
var urlParser = require('url');
var Service = require('webos-service');

var service = new Service('com.rtspdream.webos.service');
var activeSession = null;

function bufAlloc(size) {
  if (typeof Buffer.alloc === 'function') return Buffer.alloc(size);
  var b = new Buffer(size);
  b.fill(0);
  return b;
}

function bufFromStr(str, enc) {
  if (typeof Buffer.from === 'function') return Buffer.from(str, enc || 'utf8');
  return new Buffer(str, enc || 'utf8');
}

function bufFromArr(arr) {
  if (typeof Buffer.from === 'function') return Buffer.from(arr);
  return new Buffer(arr);
}

function parseRtspUri(rawUrl) {
  var parsed = urlParser.parse(rawUrl);
  if (!parsed || !parsed.hostname) {
    return null;
  }
  var port = parsed.port ? parseInt(parsed.port, 10) : 554;
  var username = '';
  var password = '';
  if (parsed.auth) {
    var parts = parsed.auth.split(':');
    username = decodeURIComponent(parts[0] || '');
    password = decodeURIComponent(parts.slice(1).join(':') || '');
  }
  var pathPart = parsed.path || '/';
  var cleanUrl = 'rtsp://' + parsed.hostname + ':' + port + pathPart;
  return {
    host: parsed.hostname,
    port: port,
    username: username,
    password: password,
    cleanUrl: cleanUrl
  };
}

function md5(str) {
  return crypto.createHash('md5').update(str).digest('hex');
}

function hex2(n) {
  var s = (n & 0xff).toString(16).toUpperCase();
  return s.length < 2 ? '0' + s : s;
}

function stripStartCode(nal) {
  if (!nal || nal.length < 4) return nal;
  if (nal[0] === 0 && nal[1] === 0 && nal[2] === 1) return nal.slice(3);
  if (nal[0] === 0 && nal[1] === 0 && nal[2] === 0 && nal[3] === 1) return nal.slice(4);
  return nal;
}

// --- H.264 SPS Dimension Parser (handles Baseline / Main / High profiles) ---
function parseSpsDimensions(sps) {
  if (!sps || sps.length < 4) return { width: 1920, height: 1080 };
  try {
    // Strip Annex-B emulation prevention bytes (0x00 0x00 0x03 -> 0x00 0x00)
    var rbsp = [];
    for (var i = 1; i < sps.length; i++) {
      if (i >= 2 && sps[i] === 0x03 && sps[i - 1] === 0x00 && sps[i - 2] === 0x00) {
        continue;
      }
      rbsp.push(sps[i]);
    }
    var bitPos = 0;
    function readBits(n) {
      var val = 0;
      for (var k = 0; k < n; k++) {
        var byteIdx = bitPos >> 3;
        if (byteIdx >= rbsp.length) return 0;
        var bit = (rbsp[byteIdx] >> (7 - (bitPos & 7))) & 1;
        val = (val << 1) | bit;
        bitPos++;
      }
      return val;
    }
    function readUE() {
      var zeros = 0;
      while (bitPos < rbsp.length * 8 && readBits(1) === 0) {
        zeros++;
        if (zeros > 30) return 0;
      }
      if (zeros === 0) return 0;
      return ((1 << zeros) - 1) + readBits(zeros);
    }
    function readSE() {
      var v = readUE();
      return (v & 1) ? ((v + 1) >> 1) : -(v >> 1);
    }

    var profileIdc = readBits(8);
    readBits(16); // constraint flags + level_idc
    readUE(); // seq_parameter_set_id

    if (
      profileIdc === 100 || profileIdc === 110 || profileIdc === 122 ||
      profileIdc === 244 || profileIdc === 44 || profileIdc === 83 ||
      profileIdc === 86 || profileIdc === 118 || profileIdc === 128 ||
      profileIdc === 138 || profileIdc === 139 || profileIdc === 134
    ) {
      var chromaFormatIdc = readUE();
      if (chromaFormatIdc === 3) readBits(1);
      readUE(); // bit_depth_luma_minus8
      readUE(); // bit_depth_chroma_minus8
      readBits(1); // qpprime_y_zero_transform_bypass_flag
      var seqScalingMatrixPresentFlag = readBits(1);
      if (seqScalingMatrixPresentFlag) {
        var count = chromaFormatIdc !== 3 ? 8 : 12;
        for (var s = 0; s < count; s++) {
          if (readBits(1)) {
            var sizeOfList = s < 6 ? 16 : 64;
            var lastScale = 8;
            var nextScale = 8;
            for (var j = 0; j < sizeOfList; j++) {
              if (nextScale !== 0) {
                var deltaScale = readSE();
                nextScale = (lastScale + deltaScale + 256) % 256;
              }
              lastScale = nextScale === 0 ? lastScale : nextScale;
            }
          }
        }
      }
    }

    readUE(); // log2_max_frame_num_minus4
    var picOrderCntType = readUE();
    if (picOrderCntType === 0) {
      readUE();
    } else if (picOrderCntType === 1) {
      readBits(1);
      readSE();
      readSE();
      var numRefFrames = readUE();
      for (var r = 0; r < numRefFrames; r++) readSE();
    }

    readUE(); // max_num_ref_frames
    readBits(1); // gaps_in_frame_num_value_allowed_flag

    var picWidthInMbsMinus1 = readUE();
    var picHeightInMapUnitsMinus1 = readUE();
    var frameMbsOnlyFlag = readBits(1);
    if (!frameMbsOnlyFlag) readBits(1); // mb_adaptive_frame_field_flag
    readBits(1); // direct_8x8_inference_flag

    var cropLeft = 0, cropRight = 0, cropTop = 0, cropBottom = 0;
    if (readBits(1)) {
      cropLeft = readUE();
      cropRight = readUE();
      cropTop = readUE();
      cropBottom = readUE();
    }

    var width = (picWidthInMbsMinus1 + 1) * 16 - (cropLeft + cropRight) * 2;
    var height = (2 - frameMbsOnlyFlag) * (picHeightInMapUnitsMinus1 + 1) * 16 - (cropTop + cropBottom) * 2;
    if (width >= 64 && width <= 7680 && height >= 64 && height <= 4320) {
      return { width: width, height: height };
    }
  } catch (e) {}
  return { width: 1920, height: 1080 };
}

function buildAuthHeader(challenge, method, uri, username, password, ncCounter) {
  if (!username) return null;
  if (/^Basic/i.test(challenge)) {
    return 'Basic ' + bufFromStr(username + ':' + password).toString('base64');
  }
  if (/^Digest/i.test(challenge)) {
    var realmMatch = challenge.match(/realm="([^"]+)"/i);
    var nonceMatch = challenge.match(/nonce="([^"]+)"/i);
    if (!realmMatch || !nonceMatch) return null;
    var realm = realmMatch[1];
    var nonce = nonceMatch[1];
    var qopMatch = challenge.match(/qop="([^"]+)"/i) || challenge.match(/qop=([^,\s]+)/i);
    var opaqueMatch = challenge.match(/opaque="([^"]+)"/i);

    var ha1 = md5(username + ':' + realm + ':' + password);
    var ha2 = md5(method + ':' + uri);

    if (qopMatch && /\bauth\b/i.test(qopMatch[1])) {
      var nc = ('00000000' + (ncCounter || 1).toString(16)).slice(-8);
      var cnonce = crypto.randomBytes(8).toString('hex');
      var responseQop = md5(ha1 + ':' + nonce + ':' + nc + ':' + cnonce + ':auth:' + ha2);
      var header =
        'Digest username="' + username +
        '", realm="' + realm +
        '", nonce="' + nonce +
        '", uri="' + uri +
        '", qop=auth, nc=' + nc +
        ', cnonce="' + cnonce +
        '", response="' + responseQop + '"';
      if (opaqueMatch) header += ', opaque="' + opaqueMatch[1] + '"';
      return header;
    }

    var responseLegacy = md5(ha1 + ':' + nonce + ':' + ha2);
    var legacyHeader =
      'Digest username="' + username +
      '", realm="' + realm +
      '", nonce="' + nonce +
      '", uri="' + uri +
      '", response="' + responseLegacy + '"';
    if (opaqueMatch) legacyHeader += ', opaque="' + opaqueMatch[1] + '"';
    return legacyHeader;
  }
  return null;
}

function resolveTrackUri(baseUrl, contentBase, track) {
  var rawBase = contentBase ? contentBase.trim() : baseUrl;
  if (!track || track === '*') return rawBase;
  if (/^rtsp/i.test(track)) return track;

  var cleanTrack = track.replace(/^\/+/, '');
  var qIdx = rawBase.indexOf('?');
  if (qIdx !== -1 && !contentBase) {
    var pathOnly = rawBase.slice(0, qIdx).replace(/\/+$/, '');
    var queryOnly = rawBase.slice(qIdx);
    return pathOnly + '/' + cleanTrack + queryOnly;
  }
  return rawBase.replace(/\/+$/, '') + '/' + cleanTrack;
}

function parseSdpVideoSection(sdp, baseUrl) {
  var contentBaseMatch = sdp.match(/^Content-Base:\s*([^\r\n]+)/im);
  var contentBase = contentBaseMatch ? contentBaseMatch[1].trim() : null;

  var sections = sdp.split(/\r?\nm=/);
  var videoSec = null;
  for (var i = 1; i < sections.length; i++) {
    if (/^video\s/i.test(sections[i])) {
      videoSec = 'm=' + sections[i];
      break;
    }
  }
  if (!videoSec) {
    return { codec: 'UNKNOWN', trackUri: baseUrl, sps: null, pps: null };
  }

  var codecMatch = videoSec.match(/a=rtpmap:\d+\s+([A-Za-z0-9_-]+)/i);
  var codec = codecMatch ? codecMatch[1].toUpperCase() : 'H264';

  var ctrlMatch = videoSec.match(/a=control:([^\r\n]+)/i);
  var trackUri = resolveTrackUri(baseUrl, contentBase, ctrlMatch ? ctrlMatch[1].trim() : null);

  var sps = null;
  var pps = null;
  var sprop = videoSec.match(/sprop-parameter-sets=([^;\r\n\s]+)/i);
  if (sprop) {
    var sets = sprop[1].split(',');
    if (sets[0]) sps = stripStartCode(bufFromStr(sets[0], 'base64'));
    if (sets[1]) pps = stripStartCode(bufFromStr(sets[1], 'base64'));
  }

  return { codec: codec, trackUri: trackUri, sps: sps, pps: pps };
}

function createRtspClient(rtspUrl) {
  var info = parseRtspUri(rtspUrl);
  if (!info) return null;
  var socket = new net.Socket();
  var cseq = 1;
  var ncCounter = 1;
  var authChallenge = null;
  var sessionId = null;
  var buffer = bufAlloc(0);
  var pendingResolvers = [];
  var onInterleavedPacket = null;
  var onSocketClose = null;

  function processBuffer() {
    while (buffer.length > 0) {
      if (buffer[0] === 0x24) {
        if (buffer.length < 4) break;
        var pktLen = buffer.readUInt16BE(2);
        if (buffer.length < 4 + pktLen) break;
        var channel = buffer[1];
        var payload = buffer.slice(4, 4 + pktLen);
        buffer = buffer.slice(4 + pktLen);
        if (onInterleavedPacket) onInterleavedPacket(channel, payload);
      } else {
        var headerEnd = buffer.indexOf('\r\n\r\n');
        if (headerEnd === -1) break;
        var headerText = buffer.slice(0, headerEnd).toString('utf8');
        var clMatch = headerText.match(/Content-Length:\s*(\d+)/i);
        var bodyLen = clMatch ? parseInt(clMatch[1], 10) : 0;
        if (buffer.length < headerEnd + 4 + bodyLen) break;
        var body = buffer.slice(headerEnd + 4, headerEnd + 4 + bodyLen).toString('utf8');
        buffer = buffer.slice(headerEnd + 4 + bodyLen);

        var statusMatch = headerText.match(/^RTSP\/\d\.\d\s+(\d+)\s+(.*)$/m);
        var statusCode = statusMatch ? parseInt(statusMatch[1], 10) : 0;
        var wwwAuthMatches = headerText.match(/WWW-Authenticate:\s*(.+)$/gim);
        var selectedAuth = null;
        if (wwwAuthMatches && wwwAuthMatches.length > 0) {
          for (var a = 0; a < wwwAuthMatches.length; a++) {
            var val = wwwAuthMatches[a].replace(/^WWW-Authenticate:\s*/i, '').trim();
            if (!selectedAuth) selectedAuth = val;
            if (/^Digest\b/i.test(val)) {
              selectedAuth = val;
              break;
            }
          }
        }
        var sessMatch = headerText.match(/Session:\s*([^;\r\n]+)/im);
        if (sessMatch) sessionId = sessMatch[1].trim();
        var baseMatch = headerText.match(/Content-Base:\s*([^\r\n]+)/im);

        var resolver = pendingResolvers.shift();
        if (resolver) {
          resolver(null, {
            statusCode: statusCode,
            headers: headerText,
            body: body,
            contentBase: baseMatch ? baseMatch[1].trim() : null,
            wwwAuthenticate: selectedAuth
          });
        }
      }
    }
  }

  socket.on('data', function (chunk) {
    buffer = Buffer.concat([buffer, chunk]);
    processBuffer();
  });

  socket.on('close', function () {
    while (pendingResolvers.length > 0) {
      var r = pendingResolvers.shift();
      r(new Error('RTSP connection closed'));
    }
    if (onSocketClose) onSocketClose();
  });

  function sendRequest(method, targetUri, extraHeaders, cb, retryCount) {
    var retries = retryCount || 0;
    var callback = typeof extraHeaders === 'function' ? extraHeaders : cb;
    var headers = typeof extraHeaders === 'function' ? null : extraHeaders;

    var seq = cseq++;
    var lines = [method + ' ' + targetUri + ' RTSP/1.0', 'CSeq: ' + seq, 'User-Agent: RtspDreamWebOS/1.0'];
    if (sessionId) lines.push('Session: ' + sessionId);
    if (authChallenge) {
      var auth = buildAuthHeader(authChallenge, method, targetUri, info.username, info.password, ncCounter++);
      if (auth) lines.push('Authorization: ' + auth);
    }
    if (headers) {
      headers.forEach(function (h) { lines.push(h); });
    }
    lines.push('', '');

    var done = false;
    var timer = setTimeout(function () {
      if (done) return;
      done = true;
      if (callback) callback(new Error('RTSP ' + method + ' timed out'));
    }, 8000);

    pendingResolvers.push(function (err, resp) {
      if (done) return;
      done = true;
      clearTimeout(timer);
      if (err) {
        if (callback) callback(err);
        return;
      }
      if (resp.statusCode === 401 && resp.wwwAuthenticate && retries < 2) {
        authChallenge = resp.wwwAuthenticate;
        sendRequest(method, targetUri, headers, callback, retries + 1);
      } else {
        if (callback) callback(null, resp);
      }
    });

    try {
      socket.write(lines.join('\r\n'));
    } catch (writeErr) {
      clearTimeout(timer);
      if (callback) callback(writeErr);
    }
  }

  return {
    info: info,
    socket: socket,
    connect: function (cb) {
      var settled = false;
      var timer = setTimeout(function () {
        if (settled) return;
        settled = true;
        try { socket.destroy(); } catch (e) {}
        cb(new Error('TCP connection to ' + info.host + ':' + info.port + ' timed out'));
      }, 8000);

      socket.once('error', function (err) {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        cb(err);
      });

      socket.connect(info.port, info.host, function () {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        cb(null);
      });
    },
    sendRequest: sendRequest,
    setPacketHandler: function (fn) { onInterleavedPacket = fn; },
    setCloseHandler: function (fn) { onSocketClose = fn; },
    close: function () {
      try { socket.destroy(); } catch (e) {}
    }
  };
}

// --- ISO-BMFF fMP4 Builder for H.264 MSE Playback ---
function box(type, payload) {
  var b = bufAlloc(8 + payload.length);
  b.writeUInt32BE(b.length, 0);
  b.write(type, 4, 4, 'ascii');
  payload.copy(b, 8);
  return b;
}

function fullBox(type, version, flags, payload) {
  var hdr = bufAlloc(4);
  hdr[0] = version;
  hdr[1] = (flags >> 16) & 0xff;
  hdr[2] = (flags >> 8) & 0xff;
  hdr[3] = flags & 0xff;
  return box(type, Buffer.concat([hdr, payload]));
}

function buildFtypMoov(sps, pps) {
  var dims = parseSpsDimensions(sps);
  var width = dims.width;
  var height = dims.height;

  var ftyp = box('ftyp', bufFromStr('isom\x00\x00\x02\x00isomiso2avc1mp41', 'binary'));

  // mvhd v0 payload (96 bytes after 4-byte fullBox header):
  // 0: creation_time (4), 4: modification_time (4), 8: timescale (4), 12: duration (4),
  // 16: rate (4), 20: volume (2), 22: reserved (10), 32: matrix (36), 68: pre_defined (24), 92: next_track_ID (4)
  var mvhdPayload = bufAlloc(96);
  mvhdPayload.writeUInt32BE(90000, 8);
  mvhdPayload.writeUInt32BE(0, 12);
  mvhdPayload.writeUInt32BE(0x00010000, 16);
  mvhdPayload.writeUInt16BE(0x0100, 20);
  mvhdPayload.writeUInt32BE(0x00010000, 32);
  mvhdPayload.writeUInt32BE(0x00010000, 48);
  mvhdPayload.writeUInt32BE(0x40000000, 64);
  mvhdPayload.writeUInt32BE(2, 92);
  var mvhd = fullBox('mvhd', 0, 0, mvhdPayload);

  // tkhd v0 payload (80 bytes):
  // 0: creation_time (4), 4: modification_time (4), 8: track_ID (4), 12: reserved (4), 16: duration (4),
  // 20: reserved (8), 28: layer (2), 30: alt_group (2), 32: volume (2), 34: reserved (2),
  // 36: matrix (36), 72: width (4), 76: height (4)
  var tkhdPayload = bufAlloc(80);
  tkhdPayload.writeUInt32BE(1, 8);
  tkhdPayload.writeUInt32BE(0x00010000, 36);
  tkhdPayload.writeUInt32BE(0x00010000, 52);
  tkhdPayload.writeUInt32BE(0x40000000, 68);
  tkhdPayload.writeUInt32BE((width << 16) >>> 0, 72);
  tkhdPayload.writeUInt32BE((height << 16) >>> 0, 76);
  var tkhd = fullBox('tkhd', 0, 7, tkhdPayload);

  var mdhdPayload = bufAlloc(20);
  mdhdPayload.writeUInt32BE(90000, 8);
  mdhdPayload.writeUInt16BE(0x55c4, 16);
  var mdhd = fullBox('mdhd', 0, 0, mdhdPayload);

  var hdlrPayload = Buffer.concat([bufAlloc(4), bufFromStr('vide', 'ascii'), bufAlloc(12), bufFromStr('VideoHandler\0', 'ascii')]);
  var hdlr = fullBox('hdlr', 0, 0, hdlrPayload);

  var vmhd = fullBox('vmhd', 0, 1, bufAlloc(8));
  var urlBox = fullBox('url ', 0, 1, bufAlloc(0));
  var dref = fullBox('dref', 0, 0, Buffer.concat([bufFromArr([0, 0, 0, 1]), urlBox]));
  var dinf = box('dinf', dref);

  var avcCData = Buffer.concat([
    bufFromArr([1, sps[1] || 0x42, sps[2] || 0xc0, sps[3] || 0x1f, 0xff, 0xe1]),
    bufFromArr([(sps.length >> 8) & 0xff, sps.length & 0xff]),
    sps,
    bufFromArr([1, (pps.length >> 8) & 0xff, pps.length & 0xff]),
    pps
  ]);
  var avcC = box('avcC', avcCData);

  var avc1Header = bufAlloc(78);
  avc1Header.writeUInt16BE(1, 6);
  avc1Header.writeUInt16BE(width, 24);
  avc1Header.writeUInt16BE(height, 26);
  avc1Header.writeUInt32BE(0x00480000, 28);
  avc1Header.writeUInt32BE(0x00480000, 32);
  avc1Header.writeUInt16BE(1, 40);
  avc1Header.writeUInt16BE(24, 74);
  avc1Header.writeInt16BE(-1, 76);
  var avc1 = box('avc1', Buffer.concat([avc1Header, avcC]));

  var stsd = fullBox('stsd', 0, 0, Buffer.concat([bufFromArr([0, 0, 0, 1]), avc1]));
  var stts = fullBox('stts', 0, 0, bufAlloc(4));
  var stsc = fullBox('stsc', 0, 0, bufAlloc(4));
  var stsz = fullBox('stsz', 0, 0, bufAlloc(8));
  var stco = fullBox('stco', 0, 0, bufAlloc(4));
  var stbl = box('stbl', Buffer.concat([stsd, stts, stsc, stsz, stco]));

  var minf = box('minf', Buffer.concat([vmhd, dinf, stbl]));
  var mdia = box('mdia', Buffer.concat([mdhd, hdlr, minf]));
  var trak = box('trak', Buffer.concat([tkhd, mdia]));

  var trexPayload = bufAlloc(20);
  trexPayload.writeUInt32BE(1, 0);
  trexPayload.writeUInt32BE(1, 4);
  var trex = fullBox('trex', 0, 0, trexPayload);
  var mvex = box('mvex', trex);

  var moov = box('moov', Buffer.concat([mvhd, trak, mvex]));
  return { buffer: Buffer.concat([ftyp, moov]), width: width, height: height };
}

function buildMoofMdat(seqNum, dts, duration, nalUnits) {
  var avccSamples = [];
  for (var i = 0; i < nalUnits.length; i++) {
    var nal = nalUnits[i];
    var lenBuf = bufAlloc(4);
    lenBuf.writeUInt32BE(nal.length, 0);
    avccSamples.push(lenBuf, nal);
  }
  var samplePayload = Buffer.concat(avccSamples);

  var mfhdPayload = bufAlloc(4);
  mfhdPayload.writeUInt32BE(seqNum, 0);
  var mfhd = fullBox('mfhd', 0, 0, mfhdPayload);

  var tfhdPayload = bufAlloc(4);
  tfhdPayload.writeUInt32BE(1, 0);
  var tfhd = fullBox('tfhd', 0, 0x020000, tfhdPayload);

  var tfdtPayload = bufAlloc(8);
  tfdtPayload.writeUInt32BE(Math.floor(dts / 0x100000000), 0);
  tfdtPayload.writeUInt32BE(dts >>> 0, 4);
  var tfdt = fullBox('tfdt', 1, 0, tfdtPayload);

  var isKey = nalUnits.some(function (n) { return (n[0] & 0x1f) === 5; });
  var trunPayload = bufAlloc(20);
  trunPayload.writeUInt32BE(1, 0);
  trunPayload.writeInt32BE(0, 4);
  trunPayload.writeUInt32BE(duration || 3600, 8);
  trunPayload.writeUInt32BE(samplePayload.length, 12);
  trunPayload.writeUInt32BE(isKey ? 0x02000000 : 0x01010000, 16);
  var trun = fullBox('trun', 0, 0x000701, trunPayload);

  var traf = box('traf', Buffer.concat([tfhd, tfdt, trun]));
  var moof = box('moof', Buffer.concat([mfhd, traf]));
  var dataOffset = moof.length + 8;
  moof.writeInt32BE(dataOffset, moof.length - 16);

  var mdat = box('mdat', samplePayload);
  return Buffer.concat([moof, mdat]);
}

function encodeWsFrame(opcode, payloadBuf) {
  var len = payloadBuf.length;
  var header;
  if (len < 126) {
    header = bufAlloc(2);
    header[0] = 0x80 | opcode;
    header[1] = len;
  } else if (len < 65536) {
    header = bufAlloc(4);
    header[0] = 0x80 | opcode;
    header[1] = 126;
    header.writeUInt16BE(len, 2);
  } else {
    header = bufAlloc(10);
    header[0] = 0x80 | opcode;
    header[1] = 127;
    header.writeUInt32BE(0, 2);
    header.writeUInt32BE(len, 6);
  }
  return Buffer.concat([header, payloadBuf]);
}

function sendWsText(sock, obj) {
  try {
    if (!sock.destroyed) sock.write(encodeWsFrame(0x1, bufFromStr(JSON.stringify(obj), 'utf8')));
  } catch (e) {}
}

function sendWsBinary(sock, buf) {
  try {
    if (!sock.destroyed && (sock.writableLength || 0) < 4194304) {
      sock.write(encodeWsFrame(0x2, buf));
    }
  } catch (e) {}
}

// --- Service Methods ---
service.register('testStream', function (message) {
  var rtspUrl = (message.payload && message.payload.rtspUrl) || '';
  if (!rtspUrl) {
    message.respond({ returnValue: false, errorText: 'Missing rtspUrl' });
    return;
  }

  var client = createRtspClient(rtspUrl);
  if (!client) {
    message.respond({ returnValue: false, errorText: 'Invalid RTSP URL (missing hostname)' });
    return;
  }
  client.connect(function (connErr) {
    if (connErr) {
      client.close();
      message.respond({ returnValue: false, errorText: connErr.message || 'TCP connection failed' });
      return;
    }
    client.sendRequest('OPTIONS', client.info.cleanUrl, function () {
      client.sendRequest('DESCRIBE', client.info.cleanUrl, ['Accept: application/sdp'], function (descErr, resp) {
        client.close();
        if (descErr) {
          message.respond({ returnValue: false, errorText: descErr.message || 'RTSP DESCRIBE failed' });
          return;
        }
        if (resp.statusCode >= 400) {
          message.respond({ returnValue: false, errorText: 'RTSP DESCRIBE returned HTTP/RTSP ' + resp.statusCode });
          return;
        }
        var parsedSdp = parseSdpVideoSection(resp.body, resp.contentBase || client.info.cleanUrl);
        if (parsedSdp.codec === 'H265' || parsedSdp.codec === 'HEVC') {
          message.respond({
            returnValue: false,
            errorText: 'Camera stream is H.265 (HEVC). Switch camera to H.264 or enter a go2rtc/MediaMTX Relay URL.'
          });
          return;
        }
        var dims = parsedSdp.sps ? parseSpsDimensions(parsedSdp.sps) : null;
        message.respond({
          returnValue: true,
          codec: parsedSdp.codec,
          width: dims ? dims.width : 0,
          height: dims ? dims.height : 0,
          sdpLength: resp.body.length
        });
      });
    });
  });
});

function stopActiveSession() {
  if (!activeSession) return;
  var s = activeSession;
  activeSession = null;
  if (s.keepaliveTimer) clearInterval(s.keepaliveTimer);
  if (s.statsTimer) clearInterval(s.statsTimer);
  try {
    s.client.sendRequest('TEARDOWN', s.client.info.cleanUrl, function () {});
  } catch (e) {}
  s.client.close();
  s.wsClients.forEach(function (sock) { try { sock.destroy(); } catch (e) {} });
  s.httpClients.forEach(function (res) { try { res.end(); } catch (e) {} });
  try { s.server.close(); } catch (e) {}
}

service.register('stopStream', function (message) {
  stopActiveSession();
  message.respond({ returnValue: true });
});

service.register('startStream', function (message) {
  stopActiveSession();
  var rtspUrl = (message.payload && message.payload.rtspUrl) || '';
  if (!rtspUrl) {
    message.respond({ returnValue: false, errorText: 'Missing rtspUrl' });
    return;
  }

  var client = createRtspClient(rtspUrl);
  if (!client) {
    message.respond({ returnValue: false, errorText: 'Invalid RTSP URL (missing hostname)' });
    return;
  }
  var videoChannel = 0;
  var sps = null;
  var pps = null;
  var mimeCodec = null;
  var initSegment = null;
  var videoDims = { width: 0, height: 0 };
  var gopCache = [];
  var hasSeenKeyframe = false;

  var wsClients = [];
  var httpClients = [];
  var seqNum = 1;
  var fuaBuf = [];
  var currentAu = [];
  var lastRtpTs = null;
  var prevFlushedTs = null;
  var cumulativeDts = 0;

  var stats = {
    stage: 'connecting',
    codec: 'H264',
    rtpPackets: 0,
    bytes: 0,
    fragments: 0,
    hasSps: false,
    hasPps: false,
    hasKeyframe: false,
    width: 0,
    height: 0
  };

  var server = http.createServer(function (req, res) {
    res.writeHead(200, {
      'Content-Type': 'video/mp4',
      'Cache-Control': 'no-store',
      'Access-Control-Allow-Origin': '*'
    });
    if (initSegment) res.write(initSegment);
    for (var i = 0; i < gopCache.length; i++) {
      res.write(gopCache[i]);
    }
    httpClients.push(res);
    req.on('close', function () {
      httpClients = httpClients.filter(function (c) { return c !== res; });
    });
  });

  server.on('upgrade', function (req, sock) {
    var key = req.headers['sec-websocket-key'];
    if (!key) {
      sock.destroy();
      return;
    }
    var accept = crypto
      .createHash('sha1')
      .update(key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11')
      .digest('base64');

    sock.write(
      'HTTP/1.1 101 Switching Protocols\r\n' +
      'Upgrade: websocket\r\n' +
      'Connection: Upgrade\r\n' +
      'Sec-WebSocket-Accept: ' + accept + '\r\n\r\n'
    );

    wsClients.push(sock);
    sock.on('close', function () {
      wsClients = wsClients.filter(function (c) { return c !== sock; });
    });
    sock.on('error', function () {
      wsClients = wsClients.filter(function (c) { return c !== sock; });
    });

    sendWsText(sock, {
      type: 'stats',
      stage: stats.stage,
      codec: stats.codec,
      rtpPackets: stats.rtpPackets,
      bytes: stats.bytes,
      fragments: stats.fragments,
      hasSps: !!sps,
      hasPps: !!pps,
      hasKeyframe: hasSeenKeyframe,
      width: videoDims.width,
      height: videoDims.height
    });

    if (initSegment && mimeCodec) {
      sendWsText(sock, { type: 'codec', mime: mimeCodec, width: videoDims.width, height: videoDims.height });
      sendWsBinary(sock, initSegment);
      for (var i = 0; i < gopCache.length; i++) {
        sendWsBinary(sock, gopCache[i]);
      }
    }
  });

  function broadcastText(obj) {
    wsClients.forEach(function (sock) { sendWsText(sock, obj); });
  }

  function broadcastBinary(buf) {
    wsClients.forEach(function (sock) { sendWsBinary(sock, buf); });
    httpClients.forEach(function (res) { try { res.write(buf); } catch (e) {} });
  }

  function flushAu(ts) {
    if (!currentAu.length) return;
    var auNals = currentAu;
    currentAu = [];

    if (!initSegment && sps && pps) {
      mimeCodec = 'video/mp4; codecs="avc1.' + hex2(sps[1] || 0x42) + hex2(sps[2] || 0xc0) + hex2(sps[3] || 0x1f) + '"';
      var built = buildFtypMoov(sps, pps);
      initSegment = built.buffer;
      videoDims = { width: built.width, height: built.height };
      stats.width = built.width;
      stats.height = built.height;
      broadcastText({ type: 'codec', mime: mimeCodec, width: built.width, height: built.height });
      broadcastBinary(initSegment);
    }

    if (!initSegment) return;

    var isKey = auNals.some(function (n) { return (n[0] & 0x1f) === 5; });
    if (!hasSeenKeyframe) {
      if (!isKey) return;
      hasSeenKeyframe = true;
      stats.hasKeyframe = true;
      stats.stage = 'streaming';
    }

    var delta = 3600;
    if (prevFlushedTs !== null && ts !== prevFlushedTs) {
      var diff = (ts - prevFlushedTs) >>> 0;
      if (diff >= 900 && diff <= 45000) delta = diff;
    }
    prevFlushedTs = ts;

    var frag = buildMoofMdat(seqNum++, cumulativeDts, delta, auNals);
    cumulativeDts += delta;
    stats.fragments += 1;

    if (isKey) {
      gopCache = [frag];
    } else if (gopCache.length < 150) {
      gopCache.push(frag);
    }

    broadcastBinary(frag);
  }

  function handleNal(rawNal, ts) {
    var nal = stripStartCode(rawNal);
    if (!nal || !nal.length) return;
    var type = nal[0] & 0x1f;
    if (type === 7) {
      sps = nal;
      stats.hasSps = true;
      return;
    }
    if (type === 8) {
      pps = nal;
      stats.hasPps = true;
      return;
    }
    if (type === 6 || type === 9 || type < 1 || type > 5) {
      return;
    }
    if (lastRtpTs !== null && ts !== lastRtpTs) {
      flushAu(lastRtpTs);
    }
    lastRtpTs = ts;
    currentAu.push(nal);
  }

  client.setPacketHandler(function (channel, rtp) {
    if (channel !== videoChannel || rtp.length < 12) return;
    stats.rtpPackets += 1;
    stats.bytes += rtp.length;

    var marker = (rtp[1] & 0x80) !== 0;
    var ts = rtp.readUInt32BE(4);
    var cc = rtp[0] & 0x0f;
    var offset = 12 + cc * 4;
    if ((rtp[0] & 0x10) !== 0 && offset + 4 <= rtp.length) {
      var extLen = rtp.readUInt16BE(offset + 2);
      offset += 4 + extLen * 4;
    }
    if (offset >= rtp.length) return;
    var payload = rtp.slice(offset);
    var nalType = payload[0] & 0x1f;

    if (nalType >= 1 && nalType <= 23) {
      handleNal(payload, ts);
    } else if (nalType === 24) {
      var pos = 1;
      while (pos + 2 <= payload.length) {
        var naluSize = payload.readUInt16BE(pos);
        pos += 2;
        if (pos + naluSize > payload.length) break;
        handleNal(payload.slice(pos, pos + naluSize), ts);
        pos += naluSize;
      }
    } else if (nalType === 28 && payload.length > 2) {
      var fuHeader = payload[1];
      var start = (fuHeader & 0x80) !== 0;
      var end = (fuHeader & 0x40) !== 0;
      var reconstructedHeader = (payload[0] & 0xe0) | (fuHeader & 0x1f);
      if (start) {
        fuaBuf = [bufFromArr([reconstructedHeader]), payload.slice(2)];
      } else if (fuaBuf.length > 0) {
        fuaBuf.push(payload.slice(2));
      }
      if (end && fuaBuf.length > 0) {
        handleNal(Buffer.concat(fuaBuf), ts);
        fuaBuf = [];
      }
    }

    if (marker && fuaBuf.length === 0 && currentAu.length > 0) {
      flushAu(ts);
    }
  });

  client.setCloseHandler(function () {
    broadcastText({ type: 'error', message: 'RTSP TCP socket closed' });
  });

  server.listen(0, '127.0.0.1', function () {
    var addr = server.address();
    var wsUrl = 'ws://127.0.0.1:' + addr.port + '/stream';
    var httpUrl = 'http://127.0.0.1:' + addr.port + '/stream.mp4';
    var sessionObj = {
      client: client,
      server: server,
      wsClients: wsClients,
      httpClients: httpClients,
      keepaliveTimer: null,
      statsTimer: null
    };
    activeSession = sessionObj;

    function failStart(errMsg) {
      stopActiveSession();
      message.respond({ returnValue: false, errorText: errMsg });
    }

    client.connect(function (connErr) {
      if (connErr) return failStart(connErr.message || 'TCP connect failed');

      stats.stage = 'rtsp-options';
      client.sendRequest('OPTIONS', client.info.cleanUrl, function () {
        stats.stage = 'rtsp-describe';
        client.sendRequest('DESCRIBE', client.info.cleanUrl, ['Accept: application/sdp'], function (descErr, desc) {
          if (descErr) return failStart(descErr.message || 'RTSP DESCRIBE failed');
          if (desc.statusCode >= 400) return failStart('RTSP DESCRIBE returned ' + desc.statusCode);

          var parsedSdp = parseSdpVideoSection(desc.body, desc.contentBase || client.info.cleanUrl);
          stats.codec = parsedSdp.codec;
          if (parsedSdp.codec === 'H265' || parsedSdp.codec === 'HEVC') {
            return failStart('Camera is sending H.265 (HEVC). Switch camera stream to H.264 or enter a go2rtc Relay URL.');
          }
          if (parsedSdp.sps) {
            sps = parsedSdp.sps;
            stats.hasSps = true;
          }
          if (parsedSdp.pps) {
            pps = parsedSdp.pps;
            stats.hasPps = true;
          }

          stats.stage = 'rtsp-setup';
          client.sendRequest('SETUP', parsedSdp.trackUri, ['Transport: RTP/AVP/TCP;unicast;interleaved=0-1'], function (setupErr, setupResp) {
            if (setupErr) return failStart(setupErr.message || 'RTSP SETUP failed');
            if (setupResp.statusCode >= 400) return failStart('RTSP SETUP failed (' + setupResp.statusCode + ')');

            var interMatch = setupResp.headers.match(/interleaved=(\d+)-\d+/i);
            if (interMatch) videoChannel = parseInt(interMatch[1], 10);

            stats.stage = 'rtsp-play';
            client.sendRequest('PLAY', client.info.cleanUrl, ['Range: npt=0.000-'], function (playErr, playResp) {
              if (playErr) return failStart(playErr.message || 'RTSP PLAY failed');
              if (playResp.statusCode >= 400) return failStart('RTSP PLAY failed (' + playResp.statusCode + ')');

              stats.stage = 'waiting-rtp';
              sessionObj.keepaliveTimer = setInterval(function () {
                client.sendRequest('OPTIONS', client.info.cleanUrl, function () {});
              }, 25000);

              sessionObj.statsTimer = setInterval(function () {
                broadcastText({
                  type: 'stats',
                  stage: stats.stage,
                  codec: stats.codec,
                  rtpPackets: stats.rtpPackets,
                  bytes: stats.bytes,
                  fragments: stats.fragments,
                  hasSps: !!sps,
                  hasPps: !!pps,
                  hasKeyframe: hasSeenKeyframe,
                  width: videoDims.width,
                  height: videoDims.height
                });
              }, 1000);

              message.respond({
                returnValue: true,
                wsUrl: wsUrl,
                httpUrl: httpUrl,
                codec: parsedSdp.codec
              });
            });
          });
        });
      });
    });
  });
});
