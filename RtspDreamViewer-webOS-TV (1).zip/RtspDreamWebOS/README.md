# RtspDreamViewer — LG webOS TV

Fullscreen RTSP, HLS, MJPEG, and `go2rtc` stream viewer and Screensaver Mode app for LG webOS Smart TVs (`.ipk` package with a built-in Node.js Luna RTSP-over-TCP service).

## Features

- **Built-in Luna JS RTSP-to-fMP4 Bridge (`service/rtsp_service.js`)**: Connects directly to `rtsp://` IP cameras over TCP (`RTP/AVP/TCP`) with Basic & Digest authentication, parses H.264 SPS/PPS, and muxes into fragmented MP4 for hardware-accelerated MSE playback on webOS TV.
- **Direct HTTP/HLS, MJPEG & Snapshot Support**: Plays `http(s)://.../stream.m3u8`, MJPEG (`video.cgi`), and JPEG snapshot URLs directly.
- **Optional go2rtc / MediaMTX Relay**: Enter a local relay base URL in Settings for HEVC (H.265), 4K, or AAC audio transcoding.
- **10-Foot Magic Remote & D-Pad UI**: Overscan-safe Settings screen, auto-hiding floating gear button (`OK` / `Menu` / tap), `Back (461)` handling, and `com.webos.service.tvpower` screensaver suppression while actively viewing.
- **OLED Screensaver Mode**: Zero-overlay fullscreen playback (`Screensaver Mode` button or `index.html?mode=screensaver`), plus `homebrew/appinfo.json` (`defaultWindowType: "screenSaver"`) for rooted `webosbrew` TVs.

## Build the `.ipk` Locally

```bash
npm install -g @webos-tools/cli
mkdir -p build/webapp dist
cp appinfo.json index.html styles.css app.js icon.png largeIcon.png build/webapp/
ares-package build/webapp service --no-minify -o dist
```

Or push this folder to a GitHub repository and run the included `.github/workflows/build-webos-ipk.yml` workflow to download `com.rtspdream.webos_1.0.0_all.ipk` from GitHub Actions Artifacts.

## Install on Your LG TV

1. Install **Developer Mode** from the LG Content Store on your TV and enable **Dev Mode Status** + **Key Server**.
2. Install via **webOS Dev Manager** or CLI:
   ```bash
   ares-setup-device --add mytv
   ares-install --device mytv dist/com.rtspdream.webos_1.0.0_all.ipk
   ares-launch --device mytv com.rtspdream.webos
   ```
